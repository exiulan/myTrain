//把输入数据填入text框，按等于之后进行计算

//定义三个全局变量，保留第一个及第二个输入数据，及运算符
var gCalcResult = 0;
var gMemInput = 0;
var gMemFunc = '';
//把输入的值存入text中
function Input(input) {
  var calcResult = document.getElementById('result').value;
  if (calcResult == 0) {
    calcResult = ''
  }
  switch (input) {
    case 'sin':
      gCalcResult = Math.sin(gCalcResult);
      break;
    case 'ln':
      gCalcResult = Math.LOG2E;
      break;
    case 'cos':
      gCalcResult = Math.cos(gCalcResult);
      break;
    case 'log':
      gCalcResult = Math.log(gCalcResult);
      break;
    case 'tan':
      gCalcResult = Math.tan(gCalcResult);
      break;
    case 'e(x)':
      gCalcResult = Math.exp(gCalcResult);
      break;
    case 'X!':
      gCalcResult = Fac(gCalcResult);
      break;
    case 'pi':
      gCalcResult = Math.PI;
      break;
    case 'abs':
      gCalcResult = Math.abs(gCalcResult);
      break;
      //双输入参数保存第一个参数放入MemInput中，清除text框;保存历史运算符
    case 'X(y)':
    case '/':
    case '+':
    case '-':
    case '*':
      gMemInput = gCalcResult;
      Clear();
      gMemFunc = input;
      break;
    default:
      gCalcResult = calcResult + input;
      break;
  }
  document.getElementById('result').value = gCalcResult;
}
//清除
function Clear() {
  gCalcResult = 0;
  document.getElementById('result').value = '0';
}

//回退
function Backspace(back) {
  var curValue = document.getElementById('result').value;
  if (curValue != '0.') {
    var endValue = curValue.substring(0, curValue.length - 1);
    document.getElementById('result').value = endValue;
  }
}


//等号按钮触发计算
function Amount() {
  if (gMemInput == "" || gCalcResult == "") {
    gCalcResult = "出错"
  };
  var result;
  switch (gMemFunc) {
    case 'X(y)':
      result = Math.pow(parseFloat(gMemInput), parseFloat(gCalcResult));
      break;
    case '/':
      result = Divition(gMemInput, gCalcResult);
      break;
    case '+':
      result = Add(gMemInput, gCalcResult);
      break;
    case '-':
      result = Sub(gMemInput, gCalcResult);
      break;
    case '*':
      result = Pow(gMemInput, gCalcResult);
      break;
    default:
      ;
  }
  document.getElementById('result').value = result;
}

//加法计算
function Add(input1, input2) {
  return Number(input1) + Number(input2);
}
//减法计算
function Sub(input1, input2) {
  return input1 - input2;
}
//除法计算
function Divition(input1, input2) {
  if (input2 == 0) {
    return "出错";
  }
  return (input1 / input2);
}
//乘法计算
function Pow(input1, input2) {
  return input1 * input2;
}
//阶乘计算
function Fac(input) {
  var sum = 1;
  for (var i = 1; i <= input; i++) {
    sum = sum * i;
  }
  return sum;
}

//var clearResult=true;

/*
function Input(input){
    var calcResult=document.getElementById('result').value;
    var inputNum=0;
    var digit=0;
   switch (input){
       // 输入数字
       case 0:
       case 1:
       case 2:
       case 3:
       case 4:
       case 5:
       case 6:
       case 7:
       case 8:
       case 9:
           inputNum = inputNum+digit*10+input;
           break;
       //   输入函数
       case 'X(y)':
           calcResult=Math.pow(inputNum,inputNum2);
           break;
       case  '/':
           calcResult=Divition(inputNum,inputNum2);
           break;
       case  '+':
           calcResult=Add(inputNum,inputNum2);
           break;
       case  '-':
           calcResult=Sum(inputNum,inputNum2);
           break;
       case  '*':
           calcResult=Pow(inputNum,inputNum2);
           break;
       default:;
   }
}
*/