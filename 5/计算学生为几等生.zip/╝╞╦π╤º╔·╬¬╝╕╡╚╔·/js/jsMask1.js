function CalcNum() {
    var input = document.getElementById("input");
    var scord = input.value;

    var result;
    if (scord < 10 && scord >= 0) {
        result = 10;
    } else if (scord < 20 && scord >= 10) {
        result = 9;
    } else if (scord < 30 && scord >= 20) {
        result = 8;
    } else if (scord < 40 && scord >= 30) {
        result = 7
    } else if (scord < 50 && scord >= 40) {
        result = 6
    } else if (scord < 60 && scord >= 50) {
        result = 5
    } else if (scord < 70 && scord >= 60) {
        result = 4
    } else if (scord < 80 && scord >= 70) {
        result = 3
    } else if (scord < 90 && scord >= 80) {
        result = 2
    } else if (scord <= 100 && scord >= 90) {
        result = 1
    }
    if (result == undefined) {
        input.value = "输入错误"
    } else {
        input.value = "第" + result + "等生"
    }
}
