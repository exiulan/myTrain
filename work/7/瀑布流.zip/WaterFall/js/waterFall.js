$(function() {
    /*
    瀑布流实现思路：
        1、获取当前window的宽度和box的宽度，得出每行可摆放图片的个数
        2、保存每一列的当前高度放入数组中
        3、把第二行第一个图片放在高度最小的图片下方
    滚动加载数据：
        1、获取最后一张图片的高度
        2、获取当前文档的高度
        3、当当前文档的高度加上滚动的高度大于最后一张图片的高度时加载数据
     */
    $(window).load(function() {
        //瀑布流布局
        ImgPos();
        //滚动加载数据：
        var dataImage = {
            "data": [{
                "src": "111.jpg"
            }, {
                "src": "112.jpg"
            }, {
                "src": "113.jpg"
            }, {
                "src": "114.jpg"
            }, {
                "src": "115.jpg"
            }, {
                "src": "116.jpg"
            }, {
                "src": "117.jpg"
            }, {
                "src": "118.jpg"
            }, {
                "src": "119.jpg"
            }, {
                "src": "120.jpg"
            }]
        };
        $(window).scroll(function() {
            if (ScrollData()) {
                $.each(dataImage.data, function(index, value) {
                    var box = $("<div>").addClass("box").appendTo($("#container"));
                    var content = $("<div>").addClass("content").appendTo(box);
                    $("<img>").attr("src", "./WaterFallImage/" + $(value).attr("src")).appendTo(content);
                    $("<span>").text("宋智孝").appendTo(content);
                })
                ImgPos();
            }
        })

    });

});

//滚动加载数据
function ScrollData() {
    var box = $(".box");
    var lastHeight = box.last().get(0).offsetTop + Math.floor(box.last().height() / 2);
    var documentHeight = $(document).width();
    var height = $(window).scrollTop() + documentHeight;
    return ((lastHeight < height) ? true : false)
}

//瀑布流布局
function ImgPos() {
    //获得元素的个数
    var box = $(".box");
    var boxWidth = box.eq(0).width();
    var num = Math.floor($(window).width() / boxWidth);
    //获取元素的高度
    var boxArr = []; //保存元素的高度
    box.each(function(index, value) {
        var boxHeight = box.eq(index).height();
        if (index < num) {
            boxArr[index] = boxHeight;
        } else {
            var minHeight = Math.min.apply(null, boxArr);
            var minBoxIndex = $.inArray(minHeight, boxArr);
            $(value).css({
                "position": "absolute",
                "left": box.eq(minBoxIndex).position().left,
                "top": minHeight
            })
            boxArr[minBoxIndex] = boxArr[minBoxIndex] + $(box).eq(index).height();
        }
    })

}