/*
 如果设置元素鼠标enter之后显示菜单栏
 如果选择了某个菜单该菜单的背景颜色变为蓝色，否则菜单栏隐藏
 jQuery查找子元素>,find,.children
 更多产品mouseover之后显示下拉菜单、滑动滚动条加载图片
 */
$(function() {
    var hasMenu = 0;
    $("#setShow").mouseenter(function() {
        $("#bdpfmenu").css("display", "block");
        hasMenu = 1;
    }).mouseleave(function() {
        hasMenu = 0;
        $("#bdpfmenu").mouseleave(function() {
            $("#bdpfmenu").css("display", "none");
        }).mouseenter(function() {
            hasMenu = 1;
        });
        setTimeout(function() {
            if (hasMenu == 0) {
                $("#bdpfmenu").css("display", "none")
            };
        }, 100)
    });

    /*
       当鼠标经过更多产品时，显示下方nav
        briscrollwrapper高度随着浏览器可视高度变化而变化,
        滚动条的可滑动高度为当前浏览器可视高度减去title高度
        当浏览器滚动时:
            滑动块距离顶部的高度变化；
            briscrollwrapper的高度为浏览器可视高度加上浏览器滑动高度
     */
    $("#moreAbout").mouseover(function() {
        var clientHeight; //当前浏览器可视高度
        $("#bdbri").css("display", "block");
        clientHeight = document.documentElement.clientHeight;
        $("#bdbriscroll-ctrl-scroll").css("display", "block");
        $(window).resize(function() {
            clientHeight = document.documentElement.clientHeight;
            $("#briscrollwrapper").css({
                "height": clientHeight
            });
            $("#bdbriscroll-ctrl-scroll").css({
                "display": "block",
                "height": clientHeight - 40
            });
        })
        $(window).scroll(function() {
            var scrollHeight = $(window).scrollTop();
            var height = clientHeight + scrollHeight;
            if (scrollHeight > 600) {
                scrollHeight = 600
            };
            if (height > 600) {
                height = 600
            };
            $("#slider").css({
                "top": scrollHeight
            });
            $("#briscrollwrapper").css({
                "height": height
            });
        })
    });
    $("#bdbri").mouseleave(function() {
        $("#bdbriscroll-ctrl-scroll").css("display", "none")
        $("#bdbri").css("display", "none")
    });
    /*
        内容部分标签切换，内容变化
        实现思路：添加删除class属性
     */
    $("#s_shipin_head a").each(function(index) {
        var aNode = $(this);
        aNode.on("click", function() {
            $("#s_shipin_head a").removeClass("cur-tag");
            aNode.addClass("cur-tag");
            $("#imag-content div").removeClass("show").eq(index).addClass("show");
        })
    })

    //返回顶部
    $("#gotop-imag").mouseover(function() {
        $("#gotop-text").css({
            "display": "block",
            "color": "#222",
            "background-color": " #7a7a7a"
        })
    }).mouseleave(function() {
        $("#gotop-text").css({
            "display": "none"
        })
    }).on("click", function() {
        $(window).scrollTop(0);
    })
})