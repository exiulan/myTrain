

    <?php
        header("Content-Type:application/json;charset=utf-8");
        header("access-control-allow-origin: *");
        //连接数据库
        $con=mysql_connect("localhost","root",'');
        if(!$con){
            die('Could not connect:'.mysql_error());
        }
        //从数据库中选取数据
        mysql_select_db("mybaidunews",$con);//连接数据库
        mysql_query("SET NAMES 'UTF8'");
        $result=mysql_query("SELECT * FROM baidunews");//读取baidunews中数据
        $arr=array();
        while($row=mysql_fetch_array($result)) 
        {
            // echo $row['baiduNewsTitle']." ".$row['baiduNewsContent'];
            // echo "<br/>";
            array_push($arr, array('baiduNewsId'=>$row['baiduNewsId'],'baiduNewsTitle'=>$row['baiduNewsTitle'],'baiduNewsSite'=>$row['baiduNewsSite'], 'baiduNewsImg'=>$row['baiduNewsImg'],'baiduNewsContent'=>$row['baiduNewsContent'], 'baiduNewsTime'=>$row['baiduNewsTime']));
        };
        echo json_encode($arr,JSON_UNESCAPED_UNICODE);  

        mysql_close($con);
    ?>
