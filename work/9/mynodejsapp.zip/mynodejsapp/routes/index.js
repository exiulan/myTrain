var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/baiduNews', function(req, res, next) {
  res.render('baiduNews', { title: 'Express' });
})

router.get('/manageSystem', function(req, res, next) {
  res.render('manageSystem', { title: 'Express' });
})
module.exports = router;
