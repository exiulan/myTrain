var express = require('express');
var router = express.Router();
var dbHandle = require('../database/dbHandle');
/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

// 设置路由同时支持get,post
router.get('/addUser', function(req, res, next) {
    dbHandle.add(req, res, next);
});
router.post('/addUser', function(req, res, next) {
    dbHandle.add(req, res, next);
});

router.get('/queryAll', function(req, res, next) {
    dbHandle.queryAll(req, res, next);
});
router.post('/queryAll', function(req, res, next) {
    console.log('查询所有user');
    dbHandle.queryAll(req, res, next);
});

router.get('/query', function(req, res, next) {
    dbHandle.queryById(req, res, next);
});
router.post('/query', function(req, res, next) {
    dbHandle.queryById(req, res, next);
});

router.get('/deleteUser', function(req, res, next) {
    dbHandle.delete(req, res, next);
});
router.post('/deleteUser', function(req, res, next) {
    dbHandle.delete(req, res, next);
});

router.get('/updateUser', function(req, res, next) {
    dbHandle.update(req, res, next);
});
router.post('/updateUser', function(req, res, next) {
    dbHandle.update(req, res, next);
});
module.exports = router;
