$(function() {
    /*
     新闻导航点击之后下划线变化
     */
    $("#nav ul li a").click(function() {
            $(".cur").removeClass("cur");
            $(this).addClass("cur");
            /*
                分页功能实现，分为推荐和百家两个页面
            */
            var listValue = this.text;
            var hasShow = $(".newsIndexList").find(".index-list");
            hasShow.hide();
            if (listValue == "推荐") {
                console.log("推荐");
                hasShow.eq(0).show();
            } else if (listValue == "百家") {
                console.log("百家");
                hasShow.eq(1).show();
            }
        })
        /*
         热点部分的轮播图
         最后一张到第一张去除动画
         */
    var ulNav = $(".hotword-content li");
    var ul = $(".hotword-content");
    var num = ulNav.length; //获取li的个数
    var height = ulNav.height(); //获取height高度
    ul.css("height", height * num + "px"); //设定marginTop
    var sec = 4000; //时间切换间隔
    var i = 0;
    var top = -41;
    picTimer = setInterval(timeset, sec); //指定sec毫秒后执行一次timeset函数。
    function timeset() {
        marTop();
    }

    function marTop() {
        if (i == num - 1) {
            top = -41;
            i = 0;
            ul.css({
                "top": top + "px",
                "transition": "none"
            });
        } else {
            top = top - height;
            ul.css({
                "transition": " top 1s ease-out 0s"
            });
            ul.animate({
                "top": top + "px"
            }, 100);
        }
        i = i + 1;
    }


    /*
     返回顶部
     当滚动到屏幕高度的一半时返回顶部显示，否则隐藏
     */
    var reTop = $(".gotop-globalview");
    reTop.click(function() {
        $(window).scrollTop(0);
        $(this).hide();
    })
    $(window).scroll(function() {
        var scrollHeight = $(window).scrollTop();
        var height = $(document).height() / 2; //可视高度的一半
        if (scrollHeight > height) {
            reTop.show();
        } else {
            reTop.hide();
        }
    })

    /*
       点击加载更多，向后台发送请求
     */
    var id;
    var title;
    var site;
    var img;
    var time;
    $(".refresh").click(function() {
        $.ajax({
            url: "/users/queryAll",
            type: 'get',
            data: {},
            async: true, //同步AJAX出现页面假死，异步部分加载页面（返回数据类型及事件）
            dataType: 'json',
            success: function(data) {
                // 每次读取5条todo 页面切换代码
                var length = eval(data).length;
                if (length > 5) {
                    length = 5;
                }
                console.log("success");
                console.log(data);
                for (var index = 0; index < length; index++) {
                    var item = $("<div>").addClass("index-list-item").appendTo($(".index-list"));
                    var main = $("<div>").addClass("index-list-main").addClass("showleft").appendTo(item);
                    var image = $("<div>").addClass("index-list-image").appendTo(main);
                    var text = $("<div>").addClass("index-list-main-text").appendTo(main);
                    var newsTitle = $("<div>").addClass("index-list-main-title").appendTo(text);
                    var newsContent = $("<div>").addClass("index-list-main-abs").appendTo(text);
                    var bottom = $("<div>").addClass("index-list-bottom").appendTo(main);
                    var newsTime = $("<div>").addClass("index-list-main-time").appendTo(bottom);

                    id = data[index].baiduNewsId;
                    title = data[index].baiduNewsTitle;
                    content = data[index].baiduNewsContent;
                    site = data[index].baiduNewsSite;
                    img = data[index].baiduNewsImg;
                    time = data[index].baiduNewsTime;
                    $("<img>").attr("src", img).appendTo(image);
                    newsTitle.text(title);
                    newsContent.text(content);
                    $("<b>").addClass("tip-reason tip-fillred").text("新浪头条").appendTo(newsTime);
                    $("<b>").addClass("index-list-main-site").text(site).appendTo(newsTime);
                    $("<b>").addClass("tip-time").text(time).appendTo(newsTime);
                    // 高度变化
                    var newsList = $(".newsIndexList");
                    height = newsList.height();
                    var listHeight = $(".index-list-item").height() + 5;
                    newsList.css("height", listHeight + height + "px");
                }
            },
            error: function(xhr, desc, err) {
                console.log(xhr);
                console.log("details:" + desc + "\nError:" + err);
            }
        })
    })
})
