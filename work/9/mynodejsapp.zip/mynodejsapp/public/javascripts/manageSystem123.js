var id; //id和数据表id对应
var row = 5; //row和数据表id对应
var title;
var site;
var img;
var content;
var time;

var text=$(".textarea");
var btnDefaul=$(".btn-default");
var btnPri=$(".btn-primary");
var btnWar=$(".btn-warning");
//文本框点击时边框可显示
function textBorderShow(area)
{
    $(area).parent().parent().find("textarea").css({
        "border": "1px solid #95A09C"
    });
}
//修改按钮点击时边框隐藏
function textBorderHide(fault) 
{
    $(fault).parent().parent().find("textarea").css({
        "border": "none"
    });
}

//数据修改
function upDate(fault)
{
    textBorderHide(fault);
    var tr = $(fault).parent().parent().find("textarea");
    id = $(fault).parent().parent().find("td").eq(0).text().trim();
    title = tr.eq(0).val();
    site = tr.eq(1).val();
    img = tr.eq(2).val();
    content = tr.eq(3).val();
    time = tr.eq(4).val();
    $.ajax({
        url: "/users/updateUser",
        contentType: 'applicatin/json;charset=utf-8',
        type: 'get',
        //data:{"baiduNewsTitle":title,"baiduNewsSite":site,"baiduNewsImg":img,"baiduNewsContent":content,"baiduNewsTime":time,"baiduNewsId":id},
        data: {
            "baiduNewsTitle": encodeURIComponent(title),
            "baiduNewsSite": encodeURIComponent(site),
            "baiduNewsImg": encodeURIComponent(img),
            "baiduNewsContent": encodeURIComponent(content),
            "baiduNewsTime": encodeURIComponent(time),
            "baiduNewsId": encodeURIComponent(id)
        },
        async: true, //同步AJAX出现页面假死，异步部分加载页面（返回数据类型及事件）
        dataType: 'json',
        success: function(data) {
            console.log("success");
            console.log(data);
        },
        error: function(xhr, desc, err) {
            console.log(xhr);
            console.log("details:" + desc + "\nError:" + err);
        }
    })
}

function del(warning)
{
    var tr = $(warning).parent().parent();
    id = tr.find("td").eq(0).text();
    $.ajax({
        url: "/users/deleteUser",
        type: 'get',
        data: {
            "baiduNewsId": id
        },
        async: true, //同步AJAX出现页面假死，异步部分加载页面（返回数据类型及事件）
        dataType: 'json',
        success: function(data) {
            if (data.msg != '操作失败') {
                tr.remove();
            }
            console.log(data);
        },
        error: function(xhr, desc, err) {
            console.log(xhr);
            console.log("details:" + desc + "\nError:" + err);
        }
    })
}
// 数据查询
function qur(primary)
{
    var tr = $(primary).parent().parent().find("td");
    var text = $(primary).parent().parent().find("textarea");
    id = tr.eq(0).text();
    $.ajax({
        url: "/users/query",
        type: 'get',
        contentType: 'applicatin/json;charset=utf-8',
        data: {
            'baiduNewsId': id
        },
        async: true, //同步AJAX出现页面假死，异步部分加载页面（返回数据类型及事件）
        dataType: 'json',
        success: function(data) {
            //TODO更新当前消息表
            if (data.msg != '操作失败') {
                title = data[0].baiduNewsTitle;
                site = data[0].baiduNewsSite;
                img = data[0].baiduNewsImg;
                content = data[0].baiduNewsContent;
                time = data[0].baiduNewsTime;
                text.eq(0).val(title);
                text.eq(1).val(site);
                text.eq(2).val(img);
                text.eq(3).val(content);
                text.eq(4).val(time);
            }
        },
        error: function(xhr, desc, err) {
            console.log(xhr);
            console.log("details:" + desc + "\nError:" + err);
        }
    })
}

$(function() {
    text.click(textBorderShow(this));
    btnDefaul.click(upDate(this));
    btnWar.click(del(this));
    btnPri.click(qur(this));
    $(".btn-info").click(function() {
        title = $(".title").val();
        site = $(".site").val();
        img = $(".img").val();
        content = $(".content").val();
        time = $(".time").val();
        row = row + 1;
        var id = row;
        var tr = $('<tr>').appendTo($(".newsTable"));
        var td1 = $('<td>').text(id).appendTo(tr);
        var td2 = $('<td>').appendTo(tr);
        var td3 = $('<td>').appendTo(tr);
        var td4 = $('<td>').appendTo(tr);
        var td5 = $('<td>').appendTo(tr);
        var td6 = $('<td>').appendTo(tr);
        var td7 = $('<td>').appendTo(tr);
        var textarea1 = $('<textarea>').addClass("textarea").attr('rows', '3').val(title).appendTo(td2);
        var textarea2 = $('<textarea>').addClass("textarea").attr('rows', '3').val(site).appendTo(td3);
        var textarea3 = $('<textarea>').addClass("textarea").attr('rows', '3').val(img).appendTo(td4);
        var textarea4 = $('<textarea>').addClass("textarea").attr('rows', '3').val(content).appendTo(td5);
        var textarea5 = $('<textarea>').addClass("textarea").attr('rows', '3').val(time).appendTo(td6);
        var button1 = $('<button>').addClass("btn btn-default btn-block").attr("type", "button").text("修改").attr("onclick","upDate(this)").appendTo(td7);
        var button2 = $('<button>').addClass("btn btn-warning btn-block").attr('type', 'button').text("删除").attr("onclick","del(this)").appendTo(td7);
        var button3 = $('<button>').addClass("btn btn-primary btn-block").attr('type', 'button').text("查询").attr("onclick","qur(this)").appendTo(td7);
    })
})
