
// SQL语句
var user={
	insert:'INSERT INTO `baidunews` (`baiduNewsId`, `baiduNewsTitle`, `baiduNewsSite`, `baiduNewsImg`, `baiduNewsContent`, `baiduNewsTime`) VALUES(0,?,?,?,?,?)',
	update:'UPDATE `baidunews` SET `baiduNewsTitle`=?, `baiduNewsSite`=?, `baiduNewsImg`=?, `baiduNewsContent`=?, `baiduNewsTime`=? WHERE baiduNewsId=?',
	delete:'DELETE FROM baidunews WHERE baiduNewsId=?',
	queryById:'SELECT * FROM baidunews WHERE baiduNewsId=?',
	queryAll:'SELECT * FROM baidunews',
}

module.exports = user;