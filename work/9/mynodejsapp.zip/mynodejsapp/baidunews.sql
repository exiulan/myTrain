-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2015-12-08 16:32:43
-- 服务器版本： 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mybaidunews`
--

-- --------------------------------------------------------

--
-- 表的结构 `baidunews`
--

CREATE TABLE IF NOT EXISTS `baidunews` (
  `baiduNewsId` int(11) NOT NULL COMMENT '自动增长',
  `baiduNewsTitle` varchar(100) NOT NULL,
  `baiduNewsSite` varchar(50) NOT NULL,
  `baiduNewsImg` varchar(200) NOT NULL,
  `baiduNewsContent` varchar(200) NOT NULL,
  `baiduNewsTime` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='百度新闻表';

--
-- 转存表中的数据 `baidunews`
--

INSERT INTO `baidunews` (`baiduNewsId`, `baiduNewsTitle`, `baiduNewsSite`, `baiduNewsImg`, `baiduNewsContent`, `baiduNewsTime`) VALUES
(1, '央行:个人不得拒收新版人民币', '央行网', 'http://localhost:3000/images/111.jpg', '人民银行有关部门负责人就2015年版第五套人民币100元纸币流通问题答记者问。', '2015-11-18'),
(2, 'Uber瞄准房地产界 搅局房产O2O', '中国产经新闻报', 'http://localhost:3000/images/112.jpg', 'Uber买房是基于Uber出行的一类增值服务，于Uber而言是一次“不算大”的转型举措，上升不', '2015-11-18'),
(3, '疯狂海外购：热了外商 冷了内需', '中国产经新闻报', 'http://localhost:3000/images/113.jpg', '2014年我国公民境外消费额首破1万亿元，超1亿“国际扫客”海外“扫货”。', '2015-11-19'),
(4, '美国10月CPI环比由负转正同比好于预期 支持加息', '凤凰国际', 'http://localhost:3000/images/114.jpg', '美国10月CPI环比0.2%，预期0.2%，前值-0.2%。', '2015-11-19'),
(5, 'A股跳水暗藏隐情？能否延续反弹看两条件', '凤凰财经', 'http://localhost:3000/images/115.jpg', '风云突变，两市高位震荡后跳水，沪指一度失守3600点。', '2015-11-19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `baidunews`
--
ALTER TABLE `baidunews`
  ADD PRIMARY KEY (`baiduNewsId`),
  ADD KEY `baiduNewsTitle` (`baiduNewsTitle`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `baidunews`
--
ALTER TABLE `baidunews`
  MODIFY `baiduNewsId` int(11) NOT NULL AUTO_INCREMENT COMMENT '自动增长',AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
