//页面加载首先读取localStorage和cookies的颜色值，若为空不进行操作
function ReadStorage() {
	//localStorage
	var baColor = localStorage.getItem("myColor");
	//cookies,存入的内容为字符串
	baColor=getCookie("myColor");
	if (baColor != null) {
		ChanNavBgCo(baColor); //改变导航栏背景颜色
		ChanBodyCo(baColor); //改变内容字体颜色
	}
}
//获取指定名称的cookies
function getCookie(name){
	var strCookie=document.cookie;
	var arrCookie=strCookie.split("; ");
	for(var i=0;i<arrCookie.length;i++){
		var arr=arrCookie[i].split("=");
		if(arr[0]==name)return arr[1];
	}
	return null;
}

//鼠标滑过改变颜色值
function ChangeSkin(color) {
	var baColor;
	switch (color) {
		case 'g':
			baColor = ' #72a9aa';
			break;
		case 'o':
			baColor = '#e6ff4d';
			break;
		case 'y':
			baColor = '#fc90df';
			break;
		case 'w':
			baColor = '#74fcf5';
			break;
		case 'r':
			baColor = '#fc261c';
			break;
		default:
			;
	}
	ChanNavBgCo(baColor); //改变导航栏背景颜色
	ChanBodyCo(baColor); //改变内容字体颜色
	SaveTo(baColor); //保存到缓存中
}

//改变导航栏的背景颜色
function ChanNavBgCo(baColor) {
	var nav = document.getElementById('nav-bgC');
	nav.style.backgroundColor = baColor;
}
//改变主题内容的字体颜色
function ChanBodyCo(baColor) {
	//第一部分网址通过element实现
	var navUl = document.getElementById('setColor'); //获取ul元素
	var navLi = navUl.getElementsByTagName('li'); //获取li元素
	for (var i = 0; i < navLi.length; i++) {
		var navA = navLi[i].getElementsByTagName('a'); //获取a元素
		for (var j = 0; j < navA.length; j++) {
			navA[j].style.color = baColor;
		}
	}
	//第二部分网址通过querySelectorAll实现
	var spanA = document.querySelectorAll('#topic-span span a'); //返回所有div中的span中的a
	for (var i = 0; i < spanA.length; i++) {
		spanA[i].style.color = baColor;
	}
}
//存储通过localStorage和cookies两种方式存储
//localStorage页面关闭还存在。sessionStorage页面关闭不存在（键值对存储）
function SaveTo(baColor) {
	//localStorage方式
	localStorage.setItem("myColor", baColor);
	//cookies方式
	var date=new Date();
	var expiresDays=10;
	//将date设置为10天以后的时间
	date.setTime(date.getTime()+expiresDays*24*3600*1000);
	//将userId和userName两个cookie设置为10天后过期
	document.cookie="myColor="+baColor+"; expires="+date.toGMTString();
}