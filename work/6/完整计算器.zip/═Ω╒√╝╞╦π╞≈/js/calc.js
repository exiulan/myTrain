//把输入数据填入text框，按等于之后进行计算

//定义三个全局变量，保留第一个及第二个输入数据，及运算符
var gCalcResult = 0;
var gMemInput = 0;
var gMemFunc = '';
//把输入的值存入text中
function Input(input) {
    var calcResult = document.getElementById('result').value;
    //if (calcResult == 0) {
    //  calcResult = ''
    //}
    switch (input) {
        case 'sin':
            gCalcResult = Math.sin(calcResult);
            break;
        case 'ln':
            gCalcResult = Math.LOG2E;
            break;
        case 'cos':
            gCalcResult = Math.cos(calcResult);
            break;
        case 'log':
            gCalcResult = Math.log(calcResult);
            break;
        case 'tan':
            gCalcResult = Math.tan(calcResult);
            break;
        case 'e(x)':
            gCalcResult = Math.exp(calcResult);
            break;
        case 'X!':
            gCalcResult = Fac(calcResult);
            break;
        case 'pi':
            gCalcResult = Math.PI;
            break;
        case 'abs':
            gCalcResult = Math.abs(calcResult);
            break;
        case '-':
            if (Number(calcResult) < 0) {
                gCalcResult = -calcResult;
            } else {
                gCalcResult = -calcResult;
            }
            break;
            //双输入参数保存第一个参数放入MemInput中，清除text框;保存历史运算符
        case 'X(y)':
        case '/':
        case '+':
        case '-':
        case '*':
            gMemInput = calcResult;
            gMemFunc = input;
            break;
            //其余按钮不断往文本框中追加
        default:
            if (gMemFunc == '' && Number(calcResult) != 0 && !isNaN(parseInt(calcResult)) || (Number(calcResult) == 0 && input == '.') || calcResult == '0.') {
                gCalcResult = calcResult + input;
            } else {
                gCalcResult = input;
            }
            break;
    }
    document.getElementById('result').value = gCalcResult;
}
//清除,复位所有变量
function Clear() {
    gCalcResult = 0;
    gMemFunc = '';
    gMemInput = 0;
    document.getElementById('result').value = '0';
}

//回退
function Backspace(back) {
    var curValue = document.getElementById('result').value;
    if (curValue != '0') {
        gCalcResult = curValue.substring(0, curValue.length - 1);
        document.getElementById('result').value = gCalcResult;
    }
}


//等号按钮触发计算
function Amount() {
    switch (gMemFunc) {
        case 'X(y)':
            gCalcResult = Math.pow(Number(gMemInput), Number(gCalcResult));
            break;
        case '/':
            gCalcResult = Divition(gMemInput, gCalcResult);
            break;
        case '+':
            gCalcResult = Add(gMemInput, gCalcResult);
            break;
        case '-':
            gCalcResult = Sub(gMemInput, gCalcResult);
            break;
        case '*':
            gCalcResult = Pow(gMemInput, gCalcResult);
            break;
        default:
            ;
    }
    document.getElementById('result').value = gCalcResult;
}

//加法计算
function Add(input1, input2) {
    return Number(input1) + Number(input2);
}
//减法计算
function Sub(input1, input2) {
    return input1 - input2;
}
//除法计算
function Divition(input1, input2) {
    return (input1 / input2);
}
//乘法计算
function Pow(input1, input2) {
    return input1 * input2;
}
//阶乘计算
function Fac(input) {
    var sum = 1;
    if (input == 0) {
        return 0
    };
    for (var i = 1; i <= Number(input); i++) {
        sum = sum * i;
    }
    return sum;
}
