/*
 实现思路：
 1、从表格中读取第一行元素作为数组值
 2、遍历数组，保存位置值放置在第二列
 3、统计出现次数最多的元素放在第三列
 */

// 把html5中第1列读取到数组myArray中
// 创建数组myArrayNum统计个数
function ResultShow() {
    Delete() //删除数据
    var table = document.getElementById("table");
    var myArray = new Array(); //创建数组，保存数组元素
    var myArrayNum = new Array(); //创建数组，保存数组元素个数
    var firstKey = table.rows.item(1).cells[0].innerHTML; //第一个key值
    for (var i = 0; i < table.rows.length - 1; i++) {
        var element = table.rows.item(i + 1).cells[0].innerHTML; //获取表格中指定的行列的值放入数组中
        myArray[i] = element;
        myArrayNum[element] = 0;
    }
    ArrayOper(myArray, myArrayNum, firstKey);
}


//重复按键删除原有数据
function Delete() {
    var table = document.getElementById("table");
    for (var i = 1; i < table.rows.length - 1; i++) {
        for (var j = 1; j < table.rows.item(i).cells.length - 1; j++) {
            table.removeChild(table.rows.item(i + 1).cells[j]);
        }
    }
}

//打印数组中元素的位置并统计个数放在数组myArrayNum中
function ArrayOper(myArray, myArrayNum, firstKey) {
    var table = document.getElementById("table");
    var td3 = document.createElement("td"); //创建第三列
    for (var i = 0; i < myArray.length; i++) {
        var td2 = document.createElement("td"); //创建第二列
        td2.innerHTML = i; //把位置值放在table中第二列
        table.rows[i + 1].appendChild(td2);
        myArrayNum = StaticNum(myArray[i], myArrayNum);
    }
    myArrayNum.sort(function(a, b) {
        return a < b ? 1 : -1
    }); //数组从大到小排序
    td3.innerHTML = "次数" + myArrayNum[firstKey] + "值" + firstKey;
    td3.setAttribute("rowSpan", myArray.length);
    table.rows[1].appendChild(td3);
}

//统计元素的个数,myArrayNum用于保存元素的个数
function StaticNum(input, myArrayNum) {
    for (var key in myArrayNum) {
        if (key == input) {
            myArrayNum[key] = myArrayNum[key] + 1;
            break;
        }
    }
    return myArrayNum;
}